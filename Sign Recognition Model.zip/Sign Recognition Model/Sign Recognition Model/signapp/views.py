from django.forms.models import BaseModelForm
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views import generic
from django.views.generic import View
from django.contrib.auth.forms import UserCreationForm
#from .models import gestureapp
from django.contrib.auth import authenticate, login
# Create your views here.

def home(request):
    return render(request, 'gestureapp/home.html')

def contact(request):
    return render(request,'gestureapp/contact.html')

def about(request):
    return render(request,'gestureapp/about.html')

def open_camera(request):
    return render(request, 'gestureapp/open_camera.html')

class ProcessedImageView(View):
    def get(self, request, *args, **kwargs):
        # Implement the logic to fetch the processed image
        # You might want to return a static image or generate it on the fly
        # ...

        # Example: Return a static image
        with open('gesture_recognition_project\static\gestureapp\Screenshot (1).png', 'rb') as img_file:
            response = HttpResponse(img_file.read(), content_type='image/png')
            return response


'''def login(request):
    return render(request, 'gestureapp/login.html')'''


class SignUp(generic.CreateView):
    form_class = UserCreationForm
    success_url= reverse_lazy('home')
    template_name = 'registration/signup.html'   



    #def form_valid(self, form):
        #view= super(SignUp, self).form_valid(form)
        #username, password= form.cleaned_data.get('username'),form.cleaned_data.get('password1')
        #user = authenticate(username= username, password= password)
        #login(self.request, user)
        #return view





